# Codex Update 2 — Smart Welcome + Polaris UI Wiring + PWA Verification

You are Codex acting as the local code integration and debugging agent for the State Not Fate static PWA.

This is Update 2: Smart Welcome + Polaris UI Wiring + PWA verification.

Do not redesign the project. Do not migrate frameworks. Do not add backend/cloud sync. Keep the app as a static browser PWA using localStorage and the existing files.

## Preflight
Run and report:

1. `pwd`
2. `git status --short`
3. `find . -maxdepth 2 -type f | sort`
4. Confirm whether the repo has:
   - `index.html`
   - `index.css`
   - `app.js`
   - `manifest.json`
   - `service-worker.js`
5. Inspect before editing:
   - `app.js`
   - `index.html`
   - `service-worker.js`
6. Identify missing inline handler targets, especially Smart Welcome handlers.
7. Run syntax checks before and after edits:
   - `node --check app.js`
   - `node --check service-worker.js`
   - `python3 -m json.tool manifest.json >/dev/null`

## Known likely issues to verify

- `index.html` includes Smart Welcome buttons calling `startSmallAction()`, `exploreFullProgram()`, `openProfileDepthSelector()`, `goToEmergencyFloor()`, and `selectState()`, but these may not exist.
- `index.html` may call `showScreen('screen-welcome')`, while `app.js` may expect screen keys like `welcome`, `intake`, `dashboard`.
- `app.js` tabs object may not include `polaris` even though `index.html` has `tab-polaris`.
- `service-worker.js` may not cache the correct assets after Polaris wiring.
- Existing welcome/Main Frame Principles HTML may be malformed or stranded after Smart Welcome insertion.
- Polaris must not hide or break Safe Box, intake, dashboard, media console, progression, worksheets, document center, or explorer.

## Tasks

1. Fix Smart Welcome routing:
   - Start Small opens the state selector.
   - Explore Full Program opens intake if not onboarded, dashboard if onboarded.
   - Personalize More opens a lightweight confirm-based quick setup path or full intake, not a long forced intake.
   - Emergency Floor opens existing Safe Box/safety flow immediately.
   - Select state maps `initiation`, `rhythm`, `environment`, `body`, `mind`, `emergency` into a valid app/Polaris day state and opens a small plan.

2. Fix screen registry and function names:
   - Add `screen-state-selector` to the screen registry.
   - Normalize both full DOM ids like `screen-welcome` and logical keys like `welcome`.
   - Export Smart Welcome functions on `window` for inline handlers.

3. Fix Polaris tab:
   - Add `polaris` to the tab registry.
   - Ensure clicking the Polaris tab renders a panel.
   - Keep all existing tabs intact.

4. Add or refine Polaris panel:
   - Enable/disable toggle.
   - Today plan based on current energy.
   - Anchors.
   - Proof points.
   - Restart/floor win mode.
   - Settings/customize guide button may be minimal; do not add a separate backend or fake account system.

5. Preserve visual system:
   - Use existing CSS variables.
   - Use existing `glass-card`, button, stat-box, and dark/glass style.
   - Do not introduce a framework or new design system.

6. PWA/service worker:
   - If Polaris is folded into `app.js`, remove unused `polaris-complete.js` script reference from `index.html`.
   - Bump the service worker cache name after app/css/html changes.
   - Cache only active core assets.
   - Ensure old stale caches are deleted on activation.

7. Testing:
   - Static checks listed above.
   - Inline handler target scan.
   - Local browser launch if possible.
   - Manual paths: first launch, Start Small, state selector, Polaris tab, enable/disable Polaris, each energy state, Safe Box, reset intake, lock/unlock if PIN is set, offline reload, mobile viewport.

## Acceptance

- No JavaScript syntax errors.
- No missing inline handler functions.
- Smart Welcome buttons work.
- Polaris tab opens and renders.
- Polaris can be enabled/disabled.
- Energy high/medium/low/collapse each produce a valid small plan.
- Existing app flows still work.
- PWA cache version is bumped.
- No clinical overclaiming.
- No fake backend/cloud sync.
- No destructive migration of existing localStorage user data.

## Deliverable

Return:

1. Files changed.
2. Bugs fixed.
3. Test commands run and results.
4. Browser observations or reason browser testing could not be completed.
5. Remaining risks.
6. Patch summary.
